
Solve a minimization problem 
1. ... 


Submission command
`zip -r project.zip *`
`zip -r project.zip * -x "p3_venv/*"`
