
#### Solve a minimization problem 

Using the max introduces new variables -> is there a way to cut down on this?

#### Submission notes

Submission command
`zip -r project.zip *`
`zip -r project.zip * -x "p3_venv/*"`
